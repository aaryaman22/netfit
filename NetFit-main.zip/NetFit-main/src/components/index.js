export {default as Cart} from './pages/Cart'
export {default as Diet} from './pages/Diet'
export {default as Home} from './pages/Home'
export {default as Shop} from './pages/Shop'
export {default as Workout} from './pages/Workout'


